# Property Portal Project

This repository contains the solution for the interview technical assessment.  It includes a simple
regression model for predicting housing prices, a FastAPI service exposing the model, a minimal
Next.js portal skeleton hosting two separate applications, a basic Spring Boot service for market
analysis and an architecture overview.

## Structure

```
property_portal/
├── model/                 # Training script and pre‑trained model
│   ├── train_model.py     # Script to train a regression model on the provided dataset
│   ├── house_price_model.pkl  # Saved scikit‑learn model (generated after running the training script)
│   └── model_info.json    # Metadata about the model (coefficients and metrics)
├── api/                   # FastAPI service exposing prediction endpoints
│   ├── main.py            # FastAPI application with /predict, /model-info and /health endpoints
│   ├── requirements.txt   # Python dependencies for the API
│   └── Dockerfile         # Container definition for the API
├── web/                   # Next.js portal (App Router) skeleton
│   ├── README.md          # Instructions for running the portal
│   ├── app/               # App Router structure
│   │   ├── layout.tsx
│   │   ├── page.tsx
│   │   └── property‑estimator/      # Application 1 (Python backend)
│   │       ├── page.tsx
│   │       └── components/
│   └── property‑analysis/            # Application 2 (Java backend)
│       ├── page.tsx
│       └── components/
├── analysis_service/      # Spring Boot service for property market analysis
│   ├── src/main/java/com/example/analysis/Application.java
│   ├── src/main/java/com/example/analysis/controller/MarketController.java
│   ├── src/main/java/com/example/analysis/model/PropertyStats.java
│   ├── src/main/java/com/example/analysis/service/MarketService.java
│   ├── pom.xml            # Maven project file
│   └── README.md          # Instructions for building and running the service
├── architecture/          # System architecture deliverables
│   ├── architecture.png   # Diagram of the proposed cloud architecture
│   └── architecture.md    # Explanation of design decisions
└── README.md (this file)
```

### Getting Started

1. **Train the model**

   ```sh
   cd model
   python train_model.py
   ```

   This will read `../House Price Dataset.csv`, train a linear regression model, evaluate it on a
   hold‑out set and save the trained model to `house_price_model.pkl` along with a
   `model_info.json` file containing coefficients and performance metrics.

2. **Run the FastAPI service**

   ```sh
   cd api
   pip install -r requirements.txt
   uvicorn main:app --reload
   ```

   The service exposes three endpoints:

   * `GET /health` – simple health check returning `{ "status": "ok" }`.
   * `POST /predict` – accepts a single property or a list of properties in JSON form and returns
     predicted prices.
   * `GET /model-info` – returns the model coefficients and evaluation metrics stored in
     `model/model_info.json`.

3. **Build the Docker image for the API**

   ```sh
   cd api
   docker build -t property‑price‑api .
   ```

   Run it locally:

   ```sh
   docker run -p 8000:8000 property‑price‑api
   ```

4. **Run the Next.js portal**

   The portal is a skeleton demonstrating the overall structure and navigation.  It provides
   separate routes for the property estimator (Python backend) and the property market analysis
   (Java backend).  To run it you will need Node.js ≥ 18 installed.

   ```sh
   cd web
   npm install
   npm run dev
   ```

5. **Build and run the Spring Boot service**

   Ensure you have JDK 21 and Maven installed.  The service reads the housing dataset and
   exposes aggregate statistics via REST endpoints.

   ```sh
   cd analysis_service
   mvn spring-boot:run
   ```

## Architecture

An overview of the proposed cloud architecture and a brief write‑up can be found in
`architecture/architecture.png` and `architecture/architecture.md`.
