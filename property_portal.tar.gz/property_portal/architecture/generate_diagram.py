"""
Generate a simple system architecture diagram for the Property Portal.

This script uses matplotlib to draw a high-level overview of the system.  It is
intended for illustrative purposes and demonstrates the relationships between the
front‑end portal, the machine learning model service and the market analysis
service, as well as supporting infrastructure.

Running this script will create `architecture.png` in the same directory.
"""

import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch


def draw_box(ax, xy, text, width=2.6, height=1.0):
    rect = FancyBboxPatch(
        xy,
        width,
        height,
        boxstyle="round,pad=0.3",
        edgecolor="black",
        facecolor="#f5f5f5"
    )
    ax.add_patch(rect)
    ax.text(
        xy[0] + width / 2,
        xy[1] + height / 2,
        text,
        ha="center",
        va="center",
        fontsize=10,
        wrap=True
    )
    return rect


def draw_arrow(ax, start, end):
    arrow = FancyArrowPatch(
        start,
        end,
        arrowstyle="->",
        mutation_scale=10,
        linewidth=1,
        color="black"
    )
    ax.add_patch(arrow)


def create_diagram(path: str):
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.axis("off")

    # Positions
    user_pos = (0.2, 4.5)
    portal_pos = (0.2, 3)
    api_py_pos = (0.2, 1.5)
    api_java_pos = (4.2, 1.5)
    data_pos = (2.2, 0.3)

    # Draw boxes
    draw_box(ax, user_pos, "Web Browser\n(End User)")
    draw_box(ax, portal_pos, "Next.js Portal\n(app router)")
    draw_box(ax, api_py_pos, "FastAPI Service\n(Python ML model)")
    draw_box(ax, api_java_pos, "Spring Boot Service\n(Java Market Analysis)")
    draw_box(ax, data_pos, "Model & Data Storage\n(Housing dataset, trained model)", width=3.0, height=1.0)

    # Draw arrows
    draw_arrow(ax, (1.5, 4.5), (1.5, 3.5))  # user to portal
    draw_arrow(ax, (1.5, 2.5), (1.5, 2.0))  # portal to Python API
    draw_arrow(ax, (4.7, 2.5), (4.7, 2.0))  # portal to Java API
    draw_arrow(ax, (2.0, 1.5), (3.7, 1.5))  # Python API to Java API (calls ML service)
    draw_arrow(ax, (1.5, 1.5), (2.5, 0.8))  # Python API to Data
    draw_arrow(ax, (4.7, 1.5), (3.8, 0.8))  # Java API to Data

    ax.set_xlim(0, 6)
    ax.set_ylim(0, 6)
    plt.tight_layout()
    fig.savefig(path, dpi=200)
    plt.close(fig)


if __name__ == "__main__":
    # Save the diagram into the same directory as this script
    import os
    from pathlib import Path
    script_dir = Path(__file__).resolve().parent
    output_path = script_dir / "architecture.png"
    create_diagram(str(output_path))