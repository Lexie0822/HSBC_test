# System Architecture Overview

The **Property Portal** comprises three primary services deployed as containers
alongside a client‑side portal.  The goal of the architecture is to be
scalable, resilient and cost‑effective while facilitating clear separation of
concerns between the machine‑learning inference API, the market analysis API
and the front‑end.

## 1. Cloud Infrastructure

- **Container orchestration**: All three services—Next.js portal, FastAPI model
  service and Spring Boot analysis service—are packaged as Docker images and
  deployed on a managed Kubernetes cluster (e.g. Amazon EKS or Google GKE).
  Kubernetes provides horizontal pod auto‑scaling based on CPU utilisation and
  custom metrics, ensuring that each component scales independently under load.
- **Load balancing**: An ingress controller (such as AWS Application Load
  Balancer or NGINX Ingress) terminates TLS, routes HTTPS requests and
  distributes traffic across the pods.  Paths (`/api/predict`, `/api/analysis`, etc.)
  are routed to the appropriate services.
- **Storage**: The housing dataset and trained model artefacts are stored in an
  object store (e.g. S3 or GCS).  At startup the FastAPI and Spring Boot
  services download their required data into an in‑memory cache; the analysis
  service recalculates aggregated statistics and exposes them via REST.
  Model versioning can be achieved via model registry and tags.  Logs and
  metrics are shipped to a centralised logging service (e.g. CloudWatch Logs or
  Elasticsearch).

## 2. Scaling and Data

- **Stateless services**: Both the FastAPI and Spring Boot services are
  stateless; they perform computations based on request payloads and the
  downloaded artefacts.  This makes them easy to replicate and scale.
- **Caching**: To reduce latency, the market analysis service computes and
  caches summary statistics on startup; these values are refreshed only when
  the underlying dataset changes.  A distributed cache (e.g. Redis) could be
  introduced if the statistics become more complex or expensive to compute.
- **Autoscaling**: The portal and APIs run in separate deployment sets.  Each
  set can scale independently based on request rate.  For example, heavy
  interactive dashboards in the portal might require more CPU, whereas model
  predictions may be CPU‑light but memory‑intensive.

## 3. CI/CD and Monitoring

- **Continuous integration**: Source code is hosted in GitHub.  GitHub Actions
  automatically run unit tests, linting and build steps on every push.  A
  successful build produces Docker images for each service and pushes them to
  a container registry (e.g. Amazon ECR).
- **Continuous deployment**: A deployment pipeline (GitHub Actions or Argo CD)
  monitors the registry for new image versions and updates the Kubernetes
  deployments via Helm or Kubernetes manifests.  Canary or blue/green
  strategies can be used to minimise downtime.
- **Monitoring**: Application logs and metrics are collected via a sidecar or
  the language runtimes’ exporters.  Prometheus scrapes metrics such as
  request latency, error rates and CPU usage; Grafana dashboards visualise
  health and performance.  Alerting rules trigger notifications to the team
  when thresholds are breached.  Tracing (e.g. OpenTelemetry) could be added
  for end‑to‑end visibility across the portal and services.

This architecture balances simplicity with scalability.  By separating
concerns, each service can be developed, tested and deployed independently
while still integrating through well‑defined REST interfaces.  Using
containerisation and managed Kubernetes provides operational resilience and
allows the system to evolve over time as additional features (e.g. model
versioning, authentication, or more complex analytics) are introduced.